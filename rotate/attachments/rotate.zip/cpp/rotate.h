#include <vector>

void energy(int n, std::vector<int> v);
void rotate(std::vector<int> t, int x);