#include <vector>

int hack();
long long collisions(std::vector<long long> x);
