#include <vector>

int Alice(int m, int e, std::vector<int> u, std::vector<int> v, int n, std::vector<int> p);

int Bob(std::vector<int> t);
