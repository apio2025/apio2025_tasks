#include "rotate.h"
#include <vector>

void energy(int n, std::vector<int> v){
    rotate({0, 1}, 1500);
    rotate({1}, 25);
}